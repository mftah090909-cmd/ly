package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.data.repository.ChatRepository
import com.example.data.repository.MessageRepository
import com.example.data.repository.UserRepository
import com.example.ui.auth.AuthScreen
import com.example.ui.chats.ChatListScreen
import com.example.ui.conversation.ChatConversationScreen
import com.example.ui.profile.ProfileScreen
import com.example.ui.settings.SettingsScreen
import com.example.ui.theme.NewEraChatTheme
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            NewEraChatTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    Surface(
                        modifier = Modifier.fillMaxSize(),
                        color = MaterialTheme.colorScheme.background
                    ) {
                        AppRoot()
                    }
                }
            }
        }
    }
}

private sealed interface Screen {
    data object ChatList : Screen
    data class Conversation(val chatId: String, val chatTitle: String, val otherUserId: String?) : Screen
    data object Profile : Screen
    data object Settings : Screen
}

@Composable
fun AppRoot() {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val auth = remember { Firebase.auth }

    var currentUser by remember { mutableStateOf<FirebaseUser?>(auth.currentUser) }

    DisposableEffect(Unit) {
        val listener = FirebaseAuth.AuthStateListener { fbAuth ->
            currentUser = fbAuth.currentUser
        }
        auth.addAuthStateListener(listener)
        onDispose {
            auth.removeAuthStateListener(listener)
        }
    }

    if (currentUser == null) {
        AuthScreen(
            onAuthSuccess = {
                currentUser = Firebase.auth.currentUser
            }
        )
    } else {
        val user = currentUser!!
        val userRepository = remember { UserRepository(context) }
        val chatRepository = remember { ChatRepository(context) }
        val messageRepository = remember { MessageRepository(context) }

        // Sync presence with lifecycle
        val lifecycleOwner = LocalLifecycleOwner.current
        DisposableEffect(lifecycleOwner, user.uid) {
            val observer = LifecycleEventObserver { _, event ->
                coroutineScope.launch {
                    when (event) {
                        Lifecycle.Event.ON_RESUME -> userRepository.updatePresence(true)
                        Lifecycle.Event.ON_PAUSE -> userRepository.updatePresence(false)
                        else -> {}
                    }
                }
            }
            lifecycleOwner.lifecycle.addObserver(observer)
            onDispose {
                lifecycleOwner.lifecycle.removeObserver(observer)
            }
        }

        // Initialize user profile in Firestore if needed
        LaunchedEffect(user.uid) {
            val displayName = user.displayName ?: user.email?.substringBefore("@") ?: "مستخدم"
            val photoUrl = user.photoUrl?.toString()
            userRepository.createOrUpdateUserProfile(
                displayName = displayName,
                email = user.email ?: "",
                photoUrl = photoUrl
            )
        }

        var currentScreen by remember { mutableStateOf<Screen>(Screen.ChatList) }

        val currentUserName = user.displayName ?: user.email?.substringBefore("@") ?: "مستخدم"

        when (val screen = currentScreen) {
            is Screen.ChatList -> {
                ChatListScreen(
                    currentUserId = user.uid,
                    currentUserName = currentUserName,
                    chatRepository = chatRepository,
                    userRepository = userRepository,
                    onChatSelected = { chatId, chatTitle, otherUserId ->
                        currentScreen = Screen.Conversation(chatId, chatTitle, otherUserId)
                    },
                    onOpenProfile = {
                        currentScreen = Screen.Profile
                    },
                    onOpenSettings = {
                        currentScreen = Screen.Settings
                    }
                )
            }
            is Screen.Conversation -> {
                ChatConversationScreen(
                    chatId = screen.chatId,
                    chatTitle = screen.chatTitle,
                    otherUserId = screen.otherUserId,
                    currentUserId = user.uid,
                    currentUserName = currentUserName,
                    messageRepository = messageRepository,
                    userRepository = userRepository,
                    onBack = {
                        currentScreen = Screen.ChatList
                    }
                )
            }
            is Screen.Profile -> {
                ProfileScreen(
                    currentUserId = user.uid,
                    userRepository = userRepository,
                    onBack = {
                        currentScreen = Screen.ChatList
                    },
                    onSignOut = {
                        currentUser = null
                        currentScreen = Screen.ChatList
                    }
                )
            }
            is Screen.Settings -> {
                SettingsScreen(
                    onBack = {
                        currentScreen = Screen.ChatList
                    }
                )
            }
        }
    }
}
