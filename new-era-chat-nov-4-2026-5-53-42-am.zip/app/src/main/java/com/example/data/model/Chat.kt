package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class Chat(
    val chatId: String = "",
    val type: String = "direct", // "direct" or "group"
    val name: String? = null,
    val participantUids: List<String> = emptyList(),
    val participantNames: Map<String, String> = emptyMap(),
    val lastMessageText: String? = null,
    val lastMessageSenderId: String? = null,
    val lastMessageSenderName: String? = null,
    @ServerTimestamp
    val lastMessageTime: Timestamp? = null,
    val lastMessageType: String? = null, // "text", "image", "audio"
    val unreadCounts: Map<String, Long> = emptyMap(),
    @ServerTimestamp
    val createdAt: Timestamp? = null,
    @ServerTimestamp
    val updatedAt: Timestamp? = null,
    val createdBy: String = ""
) {
    fun getOtherParticipantName(currentUserId: String): String {
        if (type == "group" && !name.isNullOrBlank()) return name
        val otherUid = participantUids.firstOrNull { it != currentUserId } ?: return name ?: "مستخدم"
        return participantNames[otherUid] ?: name ?: "مستخدم New Era"
    }
}
