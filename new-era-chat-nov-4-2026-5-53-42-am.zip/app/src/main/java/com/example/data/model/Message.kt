package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class Message(
    val messageId: String = "",
    val chatId: String = "",
    val senderId: String = "",
    val senderName: String = "",
    val participantUids: List<String> = emptyList(),
    val text: String = "",
    val type: String = "text", // "text", "image", "audio"
    val mediaData: String? = null, // base64 encoded photo or audio
    val mediaDuration: Long? = null, // in seconds for voice notes
    val replyToMessageId: String? = null,
    val replyToText: String? = null,
    val readBy: List<String> = emptyList(),
    val reactions: Map<String, String> = emptyMap(), // uid -> emoji
    @ServerTimestamp
    val createdAt: Timestamp? = null,
    @ServerTimestamp
    val updatedAt: Timestamp? = null
) {
    fun isReadBy(userId: String): Boolean = readBy.contains(userId)
}
