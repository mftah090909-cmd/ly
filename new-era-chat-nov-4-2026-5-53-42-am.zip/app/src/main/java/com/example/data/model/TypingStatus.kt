package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class TypingStatus(
    val userId: String = "",
    val userName: String = "",
    val isTyping: Boolean = false,
    @ServerTimestamp
    val updatedAt: Timestamp? = null
)
