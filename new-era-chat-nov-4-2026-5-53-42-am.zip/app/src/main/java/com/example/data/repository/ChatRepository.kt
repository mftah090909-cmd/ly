package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.error.OperationType
import com.example.data.error.handleFirestoreError
import com.example.data.model.Chat
import com.example.data.model.User
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.snapshots
import com.google.firebase.firestore.toObjects
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import java.util.UUID

class ChatRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {

    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        ),
        Firebase.auth
    )


    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")
    }

    fun observeChats(): Flow<List<Chat>> = flow {
        val uid = requireUserId()
        val path = "chats"
        emitAll(
            db.collection("chats")
                .whereArrayContains("participantUids", uid)
                .snapshots()
                .map { snapshot ->
                    val chats = snapshot.toObjects<Chat>()
                    // Sort in memory by lastMessageTime descending or createdAt descending
                    chats.sortedByDescending { chat ->
                        chat.lastMessageTime?.toDate()?.time ?: chat.createdAt?.toDate()?.time ?: 0L
                    }
                }
                .catch { error ->
                    if (error is Exception) handleFirestoreError(error, OperationType.LIST, path)
                    throw error
                }
        )
    }

    suspend fun getOrCreateDirectChat(otherUser: User, currentUserName: String): Result<String> = runCatching {
        val uid = requireUserId()
        val path = "chats"

        // Check if a direct chat between these two users already exists
        val existingSnapshot = db.collection(path)
            .whereArrayContains("participantUids", uid)
            .get()
            .await()

        val existingChat = existingSnapshot.toObjects<Chat>().firstOrNull {
            it.type == "direct" && it.participantUids.contains(otherUser.userId)
        }

        if (existingChat != null) {
            return@runCatching existingChat.chatId
        }

        // Create new direct chat
        val newChatId = "chat_${UUID.randomUUID()}"
        val participantNames = mapOf(
            uid to currentUserName,
            otherUser.userId to otherUser.displayName
        )
        val payload = mapOf<String, Any>(
            "chatId" to newChatId,
            "type" to "direct",
            "participantUids" to listOf(uid, otherUser.userId),
            "participantNames" to participantNames,
            "createdAt" to FieldValue.serverTimestamp(),
            "createdBy" to uid
        )

        db.collection(path).document(newChatId).set(payload).await()
        newChatId
    }.onFailure { error ->
        if (error is Exception) handleFirestoreError(error, OperationType.CREATE, "chats")
    }

    suspend fun createGroupChat(groupName: String, selectedUsers: List<User>, currentUserName: String): Result<String> = runCatching {
        val uid = requireUserId()
        val path = "chats"
        val newChatId = "group_${UUID.randomUUID()}"

        val allUids = listOf(uid) + selectedUsers.map { it.userId }
        val namesMap = mutableMapOf(uid to currentUserName)
        selectedUsers.forEach { namesMap[it.userId] = it.displayName }

        val payload = mapOf<String, Any>(
            "chatId" to newChatId,
            "type" to "group",
            "name" to groupName,
            "participantUids" to allUids,
            "participantNames" to namesMap,
            "createdAt" to FieldValue.serverTimestamp(),
            "createdBy" to uid
        )

        db.collection(path).document(newChatId).set(payload).await()
        newChatId
    }.onFailure { error ->
        if (error is Exception) handleFirestoreError(error, OperationType.CREATE, "chats")
    }

    suspend fun deleteChat(chatId: String): Result<Unit> = runCatching {
        requireUserId()
        db.collection("chats").document(chatId).delete().await()
        Unit
    }.onFailure { error ->
        if (error is Exception) handleFirestoreError(error, OperationType.DELETE, "chats/$chatId")
    }
}
