package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.error.OperationType
import com.example.data.error.handleFirestoreError
import com.example.data.model.Message
import com.example.data.model.TypingStatus
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.snapshots
import com.google.firebase.firestore.toObjects
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import java.util.UUID

class MessageRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {

    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        ),
        Firebase.auth
    )


    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")
    }

    fun observeMessages(chatId: String): Flow<List<Message>> = flow {
        val uid = requireUserId()
        val path = "chats/$chatId/messages"
        emitAll(
            db.collection("chats")
                .document(chatId)
                .collection("messages")
                .whereArrayContains("participantUids", uid)
                .snapshots()
                .map { snapshot ->
                    val messages = snapshot.toObjects<Message>()
                    messages.sortedBy { msg -> msg.createdAt?.toDate()?.time ?: 0L }
                }
                .catch { error ->
                    if (error is Exception) handleFirestoreError(error, OperationType.LIST, path)
                    throw error
                }
        )
    }

    suspend fun sendMessage(
        chatId: String,
        senderName: String,
        participantUids: List<String>,
        text: String = "",
        type: String = "text",
        mediaData: String? = null,
        mediaDuration: Long? = null,
        replyToMessageId: String? = null,
        replyToText: String? = null
    ): Result<String> = runCatching {
        val uid = requireUserId()
        val messageId = "msg_${UUID.randomUUID()}"
        val messageDocRef = db.collection("chats").document(chatId).collection("messages").document(messageId)

        val messagePayload = mutableMapOf<String, Any>(
            "messageId" to messageId,
            "chatId" to chatId,
            "senderId" to uid,
            "senderName" to senderName,
            "participantUids" to participantUids,
            "text" to text,
            "type" to type,
            "readBy" to listOf(uid),
            "createdAt" to FieldValue.serverTimestamp()
        )
        mediaData?.let { messagePayload["mediaData"] = it }
        mediaDuration?.let { messagePayload["mediaDuration"] = it }
        replyToMessageId?.let { messagePayload["replyToMessageId"] = it }
        replyToText?.let { messagePayload["replyToText"] = it }

        // Write message
        messageDocRef.set(messagePayload).await()

        // Update chat room snippet
        val snippetText = when (type) {
            "image" -> "📷 صورة"
            "audio" -> "🎤 تسجيل صوتي"
            else -> text
        }

        val chatUpdates = mapOf<String, Any>(
            "lastMessageText" to snippetText,
            "lastMessageSenderId" to uid,
            "lastMessageSenderName" to senderName,
            "lastMessageType" to type,
            "lastMessageTime" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        db.collection("chats").document(chatId).update(chatUpdates).await()

        messageId
    }.onFailure { error ->
        if (error is Exception) handleFirestoreError(error, OperationType.CREATE, "chats/$chatId/messages")
    }

    suspend fun addReaction(chatId: String, messageId: String, emoji: String): Result<Unit> = runCatching {
        val uid = requireUserId()
        val path = "chats/$chatId/messages/$messageId"
        val docRef = db.collection("chats").document(chatId).collection("messages").document(messageId)

        docRef.update(
            "reactions.$uid", emoji,
            "updatedAt", FieldValue.serverTimestamp()
        ).await()
        Unit
    }.onFailure { error ->
        if (error is Exception) handleFirestoreError(error, OperationType.UPDATE, "chats/$chatId/messages/$messageId")
    }

    suspend fun markMessageRead(chatId: String, messageId: String): Result<Unit> = runCatching {
        val uid = requireUserId()
        val docRef = db.collection("chats").document(chatId).collection("messages").document(messageId)

        docRef.update(
            "readBy", FieldValue.arrayUnion(uid),
            "updatedAt", FieldValue.serverTimestamp()
        ).await()
        Unit
    }.onFailure { error ->
        if (error is Exception) handleFirestoreError(error, OperationType.UPDATE, "chats/$chatId/messages/$messageId")
    }

    suspend fun setTyping(chatId: String, userName: String, isTyping: Boolean): Result<Unit> = runCatching {
        val uid = auth.currentUser?.uid ?: return Result.success(Unit)
        val docRef = db.collection("chats").document(chatId).collection("typing").document(uid)

        val payload = mapOf<String, Any>(
            "userId" to uid,
            "userName" to userName,
            "isTyping" to isTyping,
            "updatedAt" to FieldValue.serverTimestamp()
        )
        docRef.set(payload).await()
        Unit
    }.onFailure { error ->
        if (error is Exception) handleFirestoreError(error, OperationType.WRITE, "chats/$chatId/typing")
    }

    fun observeTyping(chatId: String): Flow<List<TypingStatus>> = flow {
        val uid = requireUserId()
        val path = "chats/$chatId/typing"
        emitAll(
            db.collection("chats")
                .document(chatId)
                .collection("typing")
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects<TypingStatus>().filter { it.userId != uid && it.isTyping }
                }
                .catch { error ->
                    if (error is Exception) handleFirestoreError(error, OperationType.LIST, path)
                    throw error
                }
        )
    }
}
