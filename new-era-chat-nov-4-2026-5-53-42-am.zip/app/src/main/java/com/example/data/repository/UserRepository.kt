package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.error.OperationType
import com.example.data.error.handleFirestoreError
import com.example.data.model.User
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.snapshots
import com.google.firebase.firestore.toObjects
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class UserRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {

    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        ),
        Firebase.auth
    )


    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")
    }

    fun observeCurrentUser(): Flow<User?> = flow {
        val uid = requireUserId()
        val path = "users/$uid"
        emitAll(
            db.collection("users").document(uid)
                .snapshots()
                .map { snapshot -> snapshot.toObject(User::class.java) }
                .catch { error ->
                    if (error is Exception) handleFirestoreError(error, OperationType.GET, path)
                    throw error
                }
        )
    }

    suspend fun createOrUpdateUserProfile(
        displayName: String,
        email: String,
        photoUrl: String? = null,
        bio: String = "أنا أستعمل تطبيق New Era Chat! شن الجو؟"
    ): Result<Unit> = runCatching {
        val uid = requireUserId()
        val docRef = db.collection("users").document(uid)
        val existingDoc = docRef.get().await()

        if (!existingDoc.exists()) {
            val payload = mutableMapOf<String, Any>(
                "userId" to uid,
                "displayName" to displayName,
                "email" to email,
                "bio" to bio,
                "isOnline" to true,
                "createdAt" to FieldValue.serverTimestamp(),
                "lastSeen" to FieldValue.serverTimestamp()
            )
            photoUrl?.let { payload["photoUrl"] = it }
            docRef.set(payload).await()
        } else {
            val updates = mutableMapOf<String, Any>(
                "displayName" to displayName,
                "bio" to bio,
                "isOnline" to true,
                "lastSeen" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            photoUrl?.let { updates["photoUrl"] = it }
            docRef.update(updates).await()
        }
        Unit
    }.onFailure { error ->
        if (error is Exception) handleFirestoreError(error, OperationType.WRITE, "users/${auth.currentUser?.uid}")
    }

    suspend fun updatePresence(isOnline: Boolean): Result<Unit> = runCatching {
        val uid = auth.currentUser?.uid ?: return Result.success(Unit)
        val updates = mapOf<String, Any>(
            "isOnline" to isOnline,
            "lastSeen" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        db.collection("users").document(uid).update(updates).await()
        Unit
    }.onFailure { error ->
        if (error is Exception) handleFirestoreError(error, OperationType.UPDATE, "users/${auth.currentUser?.uid}")
    }

    fun searchUsers(query: String): Flow<List<User>> = flow {
        val uid = requireUserId()
        val path = "users"
        emitAll(
            db.collection("users")
                .snapshots()
                .map { snapshot ->
                    val allUsers = snapshot.toObjects<User>()
                    allUsers.filter { user ->
                        user.userId != uid && (
                            query.isBlank() ||
                            user.displayName.contains(query, ignoreCase = true) ||
                            user.email.contains(query, ignoreCase = true)
                        )
                    }
                }
                .catch { error ->
                    if (error is Exception) handleFirestoreError(error, OperationType.LIST, path)
                    throw error
                }
        )
    }

    suspend fun getUserById(userId: String): User? {
        val path = "users/$userId"
        return try {
            val doc = db.collection("users").document(userId).get().await()
            doc.toObject(User::class.java)
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, path)
            null
        }
    }
}
