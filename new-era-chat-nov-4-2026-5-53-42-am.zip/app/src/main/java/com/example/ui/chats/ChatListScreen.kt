package com.example.ui.chats

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddComment
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.GroupAdd
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.Chat
import com.example.data.model.User
import com.example.data.repository.ChatRepository
import com.example.data.repository.UserRepository
import com.example.ui.components.AvatarView
import com.example.ui.components.EmptyStateView
import com.example.ui.theme.BrandCyan
import com.example.ui.theme.BrandEmerald
import com.example.util.TimeFormatUtils
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatListScreen(
    currentUserId: String,
    currentUserName: String,
    chatRepository: ChatRepository,
    userRepository: UserRepository,
    onChatSelected: (chatId: String, chatTitle: String, otherUserId: String?) -> Unit,
    onOpenProfile: () -> Unit,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val coroutineScope = rememberCoroutineScope()
    var chats by remember { mutableStateOf<List<Chat>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var searchFilter by remember { mutableStateOf("") }
    var isSearchVisible by remember { mutableStateOf(false) }

    var showNewChatDialog by remember { mutableStateOf(false) }
    var showCreateGroupDialog by remember { mutableStateOf(false) }

    LaunchedEffect(currentUserId) {
        isLoading = true
        chatRepository.observeChats()
            .catch {
                isLoading = false
            }
            .collect { list ->
                chats = list
                isLoading = false
            }
    }

    val filteredChats = chats.filter { chat ->
        val title = chat.getOtherParticipantName(currentUserId)
        searchFilter.isBlank() || title.contains(searchFilter, ignoreCase = true) ||
                (chat.lastMessageText?.contains(searchFilter, ignoreCase = true) == true)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = stringResource(R.string.app_name),
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.ExtraBold,
                                color = BrandCyan
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(BrandEmerald)
                            )
                        }
                        Text(
                            text = stringResource(R.string.tagline_arabic),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = { isSearchVisible = !isSearchVisible },
                        modifier = Modifier.testTag("toggle_search_button")
                    ) {
                        Icon(imageVector = Icons.Default.Search, contentDescription = "بحث")
                    }
                    IconButton(
                        onClick = { showCreateGroupDialog = true },
                        modifier = Modifier.testTag("new_group_button")
                    ) {
                        Icon(imageVector = Icons.Default.GroupAdd, contentDescription = "مجموعة جديدة")
                    }
                    IconButton(
                        onClick = onOpenProfile,
                        modifier = Modifier.testTag("open_profile_button")
                    ) {
                        Icon(imageVector = Icons.Default.Person, contentDescription = "الملف الشخصي")
                    }
                    IconButton(
                        onClick = onOpenSettings,
                        modifier = Modifier.testTag("open_settings_button")
                    ) {
                        Icon(imageVector = Icons.Default.Settings, contentDescription = "الإعدادات")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showNewChatDialog = true },
                containerColor = BrandCyan,
                contentColor = Color.Black,
                shape = CircleShape,
                modifier = Modifier.testTag("new_chat_fab")
            ) {
                Icon(imageVector = Icons.Default.AddComment, contentDescription = "محادثة جديدة")
            }
        },
        modifier = modifier.testTag("chat_list_screen")
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            if (isSearchVisible) {
                OutlinedTextField(
                    value = searchFilter,
                    onValueChange = { searchFilter = it },
                    placeholder = { Text(stringResource(R.string.search_placeholder)) },
                    leadingIcon = {
                        Icon(imageVector = Icons.Default.Search, contentDescription = null)
                    },
                    shape = RoundedCornerShape(16.dp),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                        .testTag("chat_search_input")
                )
            }

            if (isLoading) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                }
            } else if (filteredChats.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    EmptyStateView(
                        icon = Icons.Default.ChatBubbleOutline,
                        title = stringResource(R.string.empty_chats_title),
                        subtitle = stringResource(R.string.empty_chats_desc)
                    )
                }
            } else {
                LazyColumn(modifier = Modifier.fillMaxSize()) {
                    items(filteredChats, key = { it.chatId }) { chat ->
                        val chatTitle = chat.getOtherParticipantName(currentUserId)
                        val otherUid = chat.participantUids.firstOrNull { it != currentUserId }

                        ChatListItem(
                            chat = chat,
                            chatTitle = chatTitle,
                            currentUserId = currentUserId,
                            onClick = {
                                onChatSelected(chat.chatId, chatTitle, otherUid)
                            }
                        )
                        HorizontalDivider(
                            modifier = Modifier.padding(start = 76.dp, end = 16.dp),
                            color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f)
                        )
                    }
                }
            }
        }
    }

    if (showNewChatDialog) {
        NewChatDialog(
            userRepository = userRepository,
            onDismiss = { showNewChatDialog = false },
            onUserSelected = { selectedUser ->
                showNewChatDialog = false
                coroutineScope.launch {
                    val result = chatRepository.getOrCreateDirectChat(selectedUser, currentUserName)
                    if (result.isSuccess) {
                        val chatId = result.getOrThrow()
                        onChatSelected(chatId, selectedUser.displayName, selectedUser.userId)
                    }
                }
            }
        )
    }

    if (showCreateGroupDialog) {
        CreateGroupDialog(
            userRepository = userRepository,
            onDismiss = { showCreateGroupDialog = false },
            onCreateGroup = { groupName, selectedUsers ->
                showCreateGroupDialog = false
                coroutineScope.launch {
                    val result = chatRepository.createGroupChat(groupName, selectedUsers, currentUserName)
                    if (result.isSuccess) {
                        val chatId = result.getOrThrow()
                        onChatSelected(chatId, groupName, null)
                    }
                }
            }
        )
    }
}

@Composable
private fun ChatListItem(
    chat: Chat,
    chatTitle: String,
    currentUserId: String,
    onClick: () -> Unit
) {
    val unreadCount = chat.unreadCounts[currentUserId] ?: 0L

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .testTag("chat_item_${chat.chatId}"),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AvatarView(
            name = chatTitle,
            size = 54.dp
        )

        Spacer(modifier = Modifier.width(14.dp))

        Column(modifier = Modifier.weight(1f)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = chatTitle,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false)
                )

                Text(
                    text = TimeFormatUtils.formatRelativeTime(chat.lastMessageTime ?: chat.createdAt),
                    style = MaterialTheme.typography.labelSmall,
                    color = if (unreadCount > 0) BrandCyan else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                val snippet = chat.lastMessageText ?: "لا توجد رسائل بعد، ابدأ الدردشة توا!"
                Text(
                    text = snippet,
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (unreadCount > 0) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
                    fontWeight = if (unreadCount > 0) FontWeight.SemiBold else FontWeight.Normal,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false)
                )

                if (unreadCount > 0) {
                    Badge(
                        containerColor = BrandCyan,
                        contentColor = Color.Black,
                        modifier = Modifier.padding(start = 8.dp)
                    ) {
                        Text(
                            text = unreadCount.toString(),
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }
    }
}
