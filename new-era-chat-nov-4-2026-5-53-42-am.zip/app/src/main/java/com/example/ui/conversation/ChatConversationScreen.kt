package com.example.ui.conversation

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Reply
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.R
import com.example.data.model.Message
import com.example.data.model.User
import com.example.data.repository.MessageRepository
import com.example.data.repository.UserRepository
import com.example.ui.components.AvatarView
import com.example.ui.theme.BrandCyan
import com.example.ui.theme.BrandEmerald
import com.example.ui.theme.OnlineGreen
import com.example.util.AudioPlayerHelper
import com.example.util.AudioRecorderHelper
import com.example.util.ImageCompressor
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatConversationScreen(
    chatId: String,
    chatTitle: String,
    otherUserId: String?,
    currentUserId: String,
    currentUserName: String,
    messageRepository: MessageRepository,
    userRepository: UserRepository,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    var messages by remember { mutableStateOf<List<Message>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var inputText by remember { mutableStateOf("") }
    var replyingToMessage by remember { mutableStateOf<Message?>(null) }
    var selectedMessageForAction by remember { mutableStateOf<Message?>(null) }

    var otherUser by remember { mutableStateOf<User?>(null) }
    var typingUsers by remember { mutableStateOf<List<String>>(emptyList()) }

    // Audio helpers
    val audioRecorder = remember { AudioRecorderHelper(context) }
    val audioPlayer = remember { AudioPlayerHelper(context) }
    var isRecordingAudio by remember { mutableStateOf(false) }
    var currentlyPlayingMessageId by remember { mutableStateOf<String?>(null) }

    BackHandler(onBack = onBack)

    // Load other user presence if direct chat
    LaunchedEffect(otherUserId) {
        if (!otherUserId.isNullOrBlank()) {
            otherUser = userRepository.getUserById(otherUserId)
        }
    }

    // Observe messages
    LaunchedEffect(chatId) {
        isLoading = true
        messageRepository.observeMessages(chatId)
            .catch { isLoading = false }
            .collect { list ->
                messages = list
                isLoading = false
                if (list.isNotEmpty()) {
                    listState.animateScrollToItem(list.size - 1)
                }
            }
    }

    // Observe typing
    LaunchedEffect(chatId) {
        messageRepository.observeTyping(chatId)
            .catch { }
            .collect { statuses ->
                typingUsers = statuses.map { it.userName.ifBlank { "شخص ما" } }
            }
    }

    // Clean up audio player and recorder on dispose
    DisposableEffect(Unit) {
        onDispose {
            audioPlayer.stopAudio()
            if (isRecordingAudio) {
                audioRecorder.cancelRecording()
            }
        }
    }

    // Photo picker launcher
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            coroutineScope.launch {
                val base64 = ImageCompressor.compressImageToBase64(context, uri)
                if (base64 != null) {
                    val participants = if (otherUserId != null) listOf(currentUserId, otherUserId) else listOf(currentUserId)
                    messageRepository.sendMessage(
                        chatId = chatId,
                        senderName = currentUserName,
                        participantUids = participants,
                        text = "",
                        type = "image",
                        mediaData = base64
                    )
                }
            }
        }
    }

    // Audio permission launcher
    val audioPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            isRecordingAudio = audioRecorder.startRecording()
        } else {
            Toast.makeText(context, context.getString(R.string.error_audio_permission), Toast.LENGTH_SHORT).show()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("conversation_back_button")
                    ) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
                    }
                },
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        AvatarView(
                            name = chatTitle,
                            photoUrl = otherUser?.photoUrl,
                            isOnline = otherUser?.isOnline == true,
                            size = 40.dp
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = chatTitle,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1
                            )
                            val statusText = when {
                                typingUsers.isNotEmpty() -> "${typingUsers.joinToString()} يكتب توا..."
                                otherUser?.isOnline == true -> "متصل توا"
                                otherUser != null -> "غير متصل"
                                else -> "مجموعة"
                            }
                            Text(
                                text = statusText,
                                style = MaterialTheme.typography.labelSmall,
                                color = if (otherUser?.isOnline == true || typingUsers.isNotEmpty()) OnlineGreen else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        modifier = modifier
            .fillMaxSize()
            .imePadding()
            .testTag("conversation_screen")
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // Message List
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                if (isLoading) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                    }
                } else if (messages.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = stringResource(R.string.empty_messages_title),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = stringResource(R.string.empty_messages_desc),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                } else {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(vertical = 8.dp)
                    ) {
                        items(messages, key = { it.messageId }) { message ->
                            val isOutgoing = message.senderId == currentUserId
                            val isPlaying = currentlyPlayingMessageId == message.messageId

                            // Automatically mark message as read if incoming and not yet read
                            LaunchedEffect(message.messageId) {
                                if (!isOutgoing && !message.readBy.contains(currentUserId)) {
                                    messageRepository.markMessageRead(chatId, message.messageId)
                                }
                            }

                            MessageBubble(
                                message = message,
                                isOutgoing = isOutgoing,
                                isPlayingAudio = isPlaying,
                                onPlayAudioClicked = {
                                    if (isPlaying) {
                                        audioPlayer.stopAudio()
                                        currentlyPlayingMessageId = null
                                    } else {
                                        message.mediaData?.let { base64 ->
                                            currentlyPlayingMessageId = message.messageId
                                            audioPlayer.playAudio(
                                                messageId = message.messageId,
                                                base64Audio = base64,
                                                onComplete = {
                                                    currentlyPlayingMessageId = null
                                                }
                                            )
                                        }
                                    }
                                },
                                onLongClick = {
                                    selectedMessageForAction = message
                                },
                                onReplyClicked = {
                                    replyingToMessage = message
                                }
                            )
                        }
                    }
                }
            }

            // Quoted reply bar
            AnimatedVisibility(visible = replyingToMessage != null) {
                replyingToMessage?.let { replyMsg ->
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Reply,
                                contentDescription = null,
                                tint = BrandCyan,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "الرد على: ${replyMsg.senderName}",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = BrandCyan
                                )
                                Text(
                                    text = replyMsg.text.ifBlank { "مرفق ميديا" },
                                    style = MaterialTheme.typography.bodySmall,
                                    maxLines = 1,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            IconButton(onClick = { replyingToMessage = null }) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "إلغاء الرد",
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Input Bar / Voice Recorder Bar
            Surface(
                color = MaterialTheme.colorScheme.surface,
                shadowElevation = 8.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                if (isRecordingAudio) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        IconButton(
                            onClick = {
                                isRecordingAudio = false
                                audioRecorder.cancelRecording()
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "إلغاء التسجيل",
                                tint = MaterialTheme.colorScheme.error
                            )
                        }

                        Text(
                            text = "جاري التسجيل الصوتي...",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )

                        IconButton(
                            onClick = {
                                isRecordingAudio = false
                                coroutineScope.launch {
                                    val audioResult = audioRecorder.stopRecording()
                                    if (audioResult != null) {
                                        val (base64Audio, duration) = audioResult
                                        val participants = if (otherUserId != null) listOf(currentUserId, otherUserId) else listOf(currentUserId)
                                        messageRepository.sendMessage(
                                            chatId = chatId,
                                            senderName = currentUserName,
                                            participantUids = participants,
                                            text = "",
                                            type = "audio",
                                            mediaData = base64Audio,
                                            mediaDuration = duration
                                        )
                                    }
                                }
                            },
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(BrandCyan)
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Send,
                                contentDescription = "إرسال التسجيل",
                                tint = Color.Black
                            )
                        }
                    }
                } else {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Media attachment button
                        IconButton(
                            onClick = {
                                photoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                            modifier = Modifier.testTag("attach_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.AttachFile,
                                contentDescription = "إرفاق صورة",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        // Text Field
                        OutlinedTextField(
                            value = inputText,
                            onValueChange = {
                                inputText = it
                                coroutineScope.launch {
                                    messageRepository.setTyping(chatId, currentUserName, it.isNotBlank())
                                }
                            },
                            placeholder = { Text(stringResource(R.string.type_message_hint)) },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = BrandCyan,
                                unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
                            ),
                            shape = RoundedCornerShape(24.dp),
                            maxLines = 4,
                            modifier = Modifier
                                .weight(1f)
                                .padding(horizontal = 4.dp)
                                .testTag("message_input_field")
                        )

                        // Send or Mic button
                        if (inputText.isNotBlank()) {
                            IconButton(
                                onClick = {
                                    val textToSend = inputText.trim()
                                    val replySnapshot = replyingToMessage
                                    inputText = ""
                                    replyingToMessage = null

                                    coroutineScope.launch {
                                        messageRepository.setTyping(chatId, currentUserName, false)
                                        val participants = if (otherUserId != null) listOf(currentUserId, otherUserId) else listOf(currentUserId)
                                        messageRepository.sendMessage(
                                            chatId = chatId,
                                            senderName = currentUserName,
                                            participantUids = participants,
                                            text = textToSend,
                                            type = "text",
                                            replyToMessageId = replySnapshot?.messageId,
                                            replyToText = replySnapshot?.text?.take(80)
                                        )
                                    }
                                },
                                modifier = Modifier
                                    .clip(CircleShape)
                                    .background(BrandCyan)
                                    .testTag("send_message_button")
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.Send,
                                    contentDescription = "إرسال",
                                    tint = Color.Black
                                )
                            }
                        } else {
                            IconButton(
                                onClick = {
                                    val permissionCheck = ContextCompat.checkSelfPermission(
                                        context,
                                        Manifest.permission.RECORD_AUDIO
                                    )
                                    if (permissionCheck == PackageManager.PERMISSION_GRANTED) {
                                        isRecordingAudio = audioRecorder.startRecording()
                                    } else {
                                        audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                    }
                                },
                                modifier = Modifier.testTag("record_audio_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Mic,
                                    contentDescription = "تسجيل صوتي",
                                    tint = BrandCyan
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Message action bottom sheet
    if (selectedMessageForAction != null) {
        val selectedMsg = selectedMessageForAction!!
        val isSentByMe = selectedMsg.senderId == currentUserId

        ModalBottomSheet(
            onDismissRequest = { selectedMessageForAction = null },
            sheetState = rememberModalBottomSheetState()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                // Quick Reaction Bar
                Text(
                    text = "تفاعل سريع",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    val emojis = listOf("👍", "❤️", "😂", "😮", "😢", "🔥")
                    emojis.forEach { emoji ->
                        Text(
                            text = emoji,
                            fontSize = 28.sp,
                            modifier = Modifier
                                .clip(CircleShape)
                                .clickable {
                                    selectedMessageForAction = null
                                    coroutineScope.launch {
                                        messageRepository.addReaction(chatId, selectedMsg.messageId, emoji)
                                    }
                                }
                                .padding(8.dp)
                        )
                    }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))

                // Reply Action
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            replyingToMessage = selectedMsg
                            selectedMessageForAction = null
                        }
                        .padding(vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(imageVector = Icons.AutoMirrored.Filled.Reply, contentDescription = null, tint = BrandCyan)
                    Spacer(modifier = Modifier.width(16.dp))
                    Text(text = "الرد على هذه الرسالة", fontWeight = FontWeight.SemiBold)
                }

                // Copy Action
                if (selectedMsg.text.isNotBlank()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                val clip = ClipData.newPlainText("Copied Text", selectedMsg.text)
                                clipboard.setPrimaryClip(clip)
                                Toast.makeText(context, context.getString(R.string.copied_to_clipboard), Toast.LENGTH_SHORT).show()
                                selectedMessageForAction = null
                            }
                            .padding(vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(imageVector = Icons.Default.AttachFile, contentDescription = null)
                        Spacer(modifier = Modifier.width(16.dp))
                        Text(text = "نسخ النص", fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
    }
}
