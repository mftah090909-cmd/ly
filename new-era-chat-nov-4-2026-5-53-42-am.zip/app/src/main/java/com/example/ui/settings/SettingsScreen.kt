package com.example.ui.settings

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PermMedia
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.BrandCyan
import com.example.ui.theme.BrandEmerald

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onBack)

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
                    }
                },
                title = {
                    Text(text = stringResource(R.string.settings_title), fontWeight = FontWeight.Bold)
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        modifier = modifier
            .fillMaxSize()
            .testTag("settings_screen")
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            Text(
                text = "إعدادات البنية التحتية والاتصال السحابي",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = BrandCyan,
                modifier = Modifier.padding(bottom = 12.dp)
            )

            SetupInfoCard(
                icon = Icons.Default.Cloud,
                title = "قاعدة بيانات Cloud Firestore",
                content = "معرّف قاعدة البيانات المخصصة:\nai-studio-android-newerach-1ad0cd11-7244-4024-8b09-436e78ea07f7\n\nتزامن لحظي فوري Snapshot Listeners للرسائل والدردشات وحالات الكتابة، متوافقة 100% مع الباقة المجانية (Free Tier / Spark)."
            )

            Spacer(modifier = Modifier.height(12.dp))

            SetupInfoCard(
                icon = Icons.Default.VerifiedUser,
                title = "المصادقة وحسابات المستخدمين",
                content = "Firebase Authentication عبر Google Sign-In باستخدام مكتبة Jetpack Credential Manager الرسمية مع تشفير فوري ومطابقة البصمة الرقمية SHA-1/SHA-256."
            )

            Spacer(modifier = Modifier.height(12.dp))

            SetupInfoCard(
                icon = Icons.Default.Security,
                title = "قواعد الأمان (Firestore Rules)",
                content = "قواعد Zero-Trust مبنية وفق الركائز الثمانية للأمان، تمنع الوصول غير المصرح، وتقيد قراءة وكتابة الرسائل فقط لأعضاء المحادثة مع التحقق الكامل من المخطط (Schema Validation)."
            )

            Spacer(modifier = Modifier.height(12.dp))

            SetupInfoCard(
                icon = Icons.Default.PermMedia,
                title = "إدارة الوسائط والتسجيلات الصوتية",
                content = "يعتمد التطبيق على معالجة وضغط ذكي للصور والتسجيلات الصوتية (AAC / Base64) بأحجام فائقة الصغر (<80KB) ليعمل التطبيق مجاناً بالكامل دون الحاجة لاشتراكات مدفوعة.\n\nإذا كنت ترغب برفع وسائط ضخمة (فيديوهات أو مستندات)، يمكنك تفعيل Firebase Storage Bucket (gen-lang-client-0319134371.firebasestorage.app) من لوحة تحكم Firebase مباشرة."
            )

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "عن التطبيق",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.padding(bottom = 12.dp)
            )

            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "New Era Chat (دردشة العصر الجديد)",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "الإصدار: 1.0 الإنتاجي (Native Kotlin + Jetpack Compose)",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "دعم كامل للاتجاه من اليمين إلى اليسار (RTL) ولهجة ليبية مرحبة وواضحة.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun SetupInfoCard(
    icon: ImageVector,
    title: String,
    content: String
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.Top
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = BrandCyan,
                modifier = Modifier
                    .size(28.dp)
                    .padding(top = 2.dp)
            )
            Spacer(modifier = Modifier.width(14.dp))
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = content,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 19.sp
                )
            }
        }
    }
}
