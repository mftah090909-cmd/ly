package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// New Era Brand Palette
val BrandCyan = Color(0xFF00E5FF)
val BrandTeal = Color(0xFF00B4D8)
val BrandEmerald = Color(0xFF10B981)
val BrandNavy = Color(0xFF0B192C)
val BrandDarkBackground = Color(0xFF08121E)
val BrandDarkSurface = Color(0xFF0F1E32)
val BrandDarkSurfaceVariant = Color(0xFF162A45)

val BrandLightBackground = Color(0xFFF4F7FB)
val BrandLightSurface = Color(0xFFFFFFFF)
val BrandLightSurfaceVariant = Color(0xFFE2E8F0)

val ChatBubbleOutgoingDark = Color(0xFF006877)
val ChatBubbleOutgoingLight = Color(0xFF00838F)
val ChatBubbleIncomingDark = Color(0xFF1E293B)
val ChatBubbleIncomingLight = Color(0xFFFFFFFF)

val OnlineGreen = Color(0xFF22C55E)
val TextPrimaryDark = Color(0xFFF1F5F9)
val TextSecondaryDark = Color(0xFF94A3B8)
val TextPrimaryLight = Color(0xFF0F172A)
val TextSecondaryLight = Color(0xFF64748B)

// M3 Theme Colors
val PrimaryDark = BrandCyan
val OnPrimaryDark = Color(0xFF00363D)
val PrimaryContainerDark = Color(0xFF004F58)
val OnPrimaryContainerDark = Color(0xFF97F0FF)

val SecondaryDark = BrandEmerald
val OnSecondaryDark = Color(0xFF003822)
val SecondaryContainerDark = Color(0xFF005234)
val OnSecondaryContainerDark = Color(0xFF66FDB0)

val PrimaryLight = Color(0xFF006874)
val OnPrimaryLight = Color(0xFFFFFFFF)
val PrimaryContainerLight = Color(0xFF97F0FF)
val OnPrimaryContainerLight = Color(0xFF001F24)

val SecondaryLight = Color(0xFF006C47)
val OnSecondaryLight = Color(0xFFFFFFFF)
val SecondaryContainerLight = Color(0xFF66FDB0)
val OnSecondaryContainerLight = Color(0xFF002112)
