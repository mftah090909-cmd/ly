package com.example.util

import android.content.Context
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.Build
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

class AudioRecorderHelper(private val context: Context) {
    private var recorder: MediaRecorder? = null
    private var tempFile: File? = null
    private var startTimeMs: Long = 0L

    fun startRecording(): Boolean {
        return try {
            tempFile = File.createTempFile("audio_note_", ".m4a", context.cacheDir)
            val mr = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                MediaRecorder(context)
            } else {
                @Suppress("DEPRECATION")
                MediaRecorder()
            }
            mr.apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setAudioEncodingBitRate(64000)
                setAudioSamplingRate(22050)
                setOutputFile(tempFile?.absolutePath)
                prepare()
                start()
            }
            recorder = mr
            startTimeMs = System.currentTimeMillis()
            true
        } catch (e: Exception) {
            e.printStackTrace()
            releaseRecorder()
            false
        }
    }

    suspend fun stopRecording(): Pair<String, Long>? = withContext(Dispatchers.IO) {
        try {
            recorder?.stop()
        } catch (e: Exception) {
            // In case recording was too short
        } finally {
            releaseRecorder()
        }

        val file = tempFile ?: return@withContext null
        val durationSec = ((System.currentTimeMillis() - startTimeMs) / 1000L).coerceAtLeast(1L)
        if (!file.exists() || file.length() == 0L) {
            file.delete()
            return@withContext null
        }

        val bytes = ByteArray(file.length().toInt())
        val fis = FileInputStream(file)
        fis.read(bytes)
        fis.close()
        file.delete()

        val base64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
        Pair("data:audio/m4a;base64,$base64", durationSec)
    }

    fun cancelRecording() {
        try {
            recorder?.stop()
        } catch (e: Exception) {
            // ignore
        } finally {
            releaseRecorder()
            tempFile?.delete()
            tempFile = null
        }
    }

    private fun releaseRecorder() {
        recorder?.release()
        recorder = null
    }
}

class AudioPlayerHelper(private val context: Context) {
    private var mediaPlayer: MediaPlayer? = null
    var currentlyPlayingMessageId: String? = null
        private set

    fun playAudio(
        messageId: String,
        base64Audio: String,
        onComplete: () -> Unit = {}
    ) {
        stopAudio()

        try {
            val cleanBase64 = if (base64Audio.contains(",")) {
                base64Audio.substringAfter(",")
            } else {
                base64Audio
            }
            val audioBytes = Base64.decode(cleanBase64, Base64.DEFAULT)
            val tempFile = File.createTempFile("play_audio_", ".m4a", context.cacheDir)
            val fos = FileOutputStream(tempFile)
            fos.write(audioBytes)
            fos.close()

            mediaPlayer = MediaPlayer().apply {
                setDataSource(tempFile.absolutePath)
                prepare()
                setOnCompletionListener {
                    currentlyPlayingMessageId = null
                    tempFile.delete()
                    onComplete()
                }
                start()
            }
            currentlyPlayingMessageId = messageId
        } catch (e: Exception) {
            e.printStackTrace()
            currentlyPlayingMessageId = null
            onComplete()
        }
    }

    fun stopAudio() {
        try {
            mediaPlayer?.stop()
            mediaPlayer?.release()
        } catch (e: Exception) {
            // ignore
        } finally {
            mediaPlayer = null
            currentlyPlayingMessageId = null
        }
    }
}
