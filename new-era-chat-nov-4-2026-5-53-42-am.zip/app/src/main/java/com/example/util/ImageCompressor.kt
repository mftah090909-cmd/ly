package com.example.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import kotlin.math.max

object ImageCompressor {
    suspend fun compressImageToBase64(context: Context, uri: Uri, maxDimension: Int = 800, quality: Int = 75): String? =
        withContext(Dispatchers.IO) {
            try {
                val inputStream = context.contentResolver.openInputStream(uri) ?: return@withContext null
                val originalBitmap = BitmapFactory.decodeStream(inputStream)
                inputStream.close()

                val width = originalBitmap.width
                val height = originalBitmap.height
                val largest = max(width, height)

                val scaledBitmap = if (largest > maxDimension) {
                    val scale = maxDimension.toFloat() / largest
                    val targetW = (width * scale).toInt()
                    val targetH = (height * scale).toInt()
                    Bitmap.createScaledBitmap(originalBitmap, targetW, targetH, true)
                } else {
                    originalBitmap
                }

                val outputStream = ByteArrayOutputStream()
                scaledBitmap.compress(Bitmap.CompressFormat.JPEG, quality, outputStream)
                val bytes = outputStream.toByteArray()
                outputStream.close()

                val base64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
                "data:image/jpeg;base64,$base64"
            } catch (e: Exception) {
                null
            }
        }
}
