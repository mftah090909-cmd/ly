package com.example.util

import com.google.firebase.Timestamp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object TimeFormatUtils {
    fun formatRelativeTime(timestamp: Timestamp?): String {
        if (timestamp == null) return "توا"
        val now = System.currentTimeMillis()
        val time = timestamp.toDate().time
        val diff = now - time

        return when {
            diff < 60 * 1000L -> "توا"
            diff < 60 * 60 * 1000L -> {
                val mins = (diff / (60 * 1000L)).toInt()
                "منذ $mins د"
            }
            diff < 24 * 60 * 60 * 1000L -> {
                val hours = (diff / (60 * 60 * 1000L)).toInt()
                "منذ $hours س"
            }
            diff < 48 * 60 * 60 * 1000L -> "أمس"
            else -> {
                val sdf = SimpleDateFormat("d MMM", Locale.forLanguageTag("ar"))
                sdf.format(Date(time))
            }
        }
    }

    fun formatMessageTime(timestamp: Timestamp?): String {
        if (timestamp == null) return ""
        val sdf = SimpleDateFormat("hh:mm a", Locale.forLanguageTag("ar"))
        return sdf.format(timestamp.toDate())
    }
}
