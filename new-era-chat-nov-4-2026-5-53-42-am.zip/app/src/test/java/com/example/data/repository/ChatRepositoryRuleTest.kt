package com.example.data.repository

import com.example.base.FirestoreEmulatorTestBase
import com.example.data.model.User
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class ChatRepositoryRuleTest : FirestoreEmulatorTestBase() {

    @Test
    fun createAndObserveChat_authenticatedUsers_succeeds(): Unit = runBlocking {
        val aliceUid = signInTestUser(ALICE_EMAIL)
        val userRepo = UserRepository(firestore, auth)
        userRepo.createOrUpdateUserProfile("Alice", ALICE_EMAIL)

        val bobUid = signInTestUser(BOB_EMAIL)
        val bobUser = User(userId = bobUid, displayName = "Bob", email = BOB_EMAIL)

        // Sign back in as Alice to create chat with Bob
        signInTestUser(ALICE_EMAIL)
        val chatRepo = ChatRepository(firestore, auth)

        val result = withTimeout(DEFAULT_TIMEOUT_MS) {
            chatRepo.getOrCreateDirectChat(bobUser, "Alice")
        }
        assertTrue("getOrCreateDirectChat failed: ${result.exceptionOrNull()?.message}", result.isSuccess)
        val chatId = result.getOrThrow()
        assertNotNull(chatId)

        // Observe chats
        val chats = withTimeout(FLOW_TIMEOUT_MS) {
            chatRepo.observeChats().first { list -> list.any { it.chatId == chatId } }
        }
        assertTrue(chats.any { it.chatId == chatId })

        // Alice sends a message
        val messageRepo = MessageRepository(firestore, auth)
        val msgResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            messageRepo.sendMessage(
                chatId = chatId,
                senderName = "Alice",
                participantUids = listOf(aliceUid, bobUid),
                text = "شن الجو يا بوب!"
            )
        }
        assertTrue("sendMessage failed: ${msgResult.exceptionOrNull()?.message}", msgResult.isSuccess)

        // Bob reads the message
        signInTestUser(BOB_EMAIL)
        val bobMsgRepo = MessageRepository(firestore, auth)
        val bobMessages = withTimeout(FLOW_TIMEOUT_MS) {
            bobMsgRepo.observeMessages(chatId).first { list -> list.isNotEmpty() }
        }
        assertTrue(bobMessages.any { it.text == "شن الجو يا بوب!" })
    }

    @Test
    fun observeChats_unauthenticatedUser_failsWithPermissionDenied(): Unit = runBlocking {
        auth.signOut()
        val chatRepo = ChatRepository(firestore, auth)

        try {
            withTimeout(FLOW_TIMEOUT_MS) {
                chatRepo.observeChats().first()
            }
            fail("Expected exception when unauthenticated")
        } catch (e: Exception) {
            val firestoreException = e.unwrapFirestoreException()
            if (firestoreException != null) {
                assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, firestoreException.code)
            } else {
                assertTrue(e is IllegalStateException || e.cause is IllegalStateException)
            }
        }
    }

    @Test
    fun getOtherUsersChat_crossUserAccess_isPrevented(): Unit = runBlocking {
        signInTestUser(ALICE_EMAIL)
        val bobUid = signInTestUser(BOB_EMAIL)

        signInTestUser(ALICE_EMAIL)
        val chatRepo = ChatRepository(firestore, auth)
        val bobUser = User(userId = bobUid, displayName = "Bob", email = BOB_EMAIL)
        val chatId = chatRepo.getOrCreateDirectChat(bobUser, "Alice").getOrThrow()

        // Charlie signs in and attempts to access Alice and Bob's chat directly
        signInTestUser(CHARLIE_EMAIL)
        try {
            withTimeout(DEFAULT_TIMEOUT_MS) {
                firestore.collection("chats").document(chatId).get().await()
            }
            fail("Expected PERMISSION_DENIED when Charlie accesses Alice and Bob's chat")
        } catch (e: Exception) {
            val fe = e.unwrapFirestoreException()
            if (fe != null) {
                assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, fe.code)
            }
        }
    }

    private companion object {
        const val ALICE_EMAIL = "alice_test@example.com"
        const val BOB_EMAIL = "bob_test@example.com"
        const val CHARLIE_EMAIL = "charlie_test@example.com"
        const val DEFAULT_TIMEOUT_MS = 6000L
        const val FLOW_TIMEOUT_MS = 5000L
    }
}
