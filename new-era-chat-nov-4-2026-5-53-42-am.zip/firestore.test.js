const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = "demo-no-project";
const ALICE_UID = "alice_123";
const BOB_UID = "bob_456";
const CHARLIE_UID = "charlie_789";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

// 1. Unauthenticated checks
test("Unauthenticated user: cannot read users, chats or messages", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("users").get());
  await assertFails(unauthDb.collection("chats").get());
});

// 2. User profile operations
test("User: can create and update own profile, but cannot update another user's profile", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const now = new Date();

  // Alice creates her profile
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).set({
      userId: ALICE_UID,
      displayName: "Alice",
      email: "alice@example.com",
      createdAt: now,
    })
  );

  // Alice updates her bio
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).update({
      bio: "شن الجو يا شباب",
      updatedAt: now,
    })
  );

  // Bob tries to update Alice's profile -> FAILS
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  await assertFails(
    bobDb.collection("users").doc(ALICE_UID).update({
      displayName: "Hacked",
    })
  );
});

// 3. Chat and Message access
test("Chat: Participants can read and write messages; non-participants are blocked", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const charlieDb = testEnv.authenticatedContext(CHARLIE_UID).firestore();
  const now = new Date();

  const chatId = "chat_alice_bob";

  // Alice creates chat between Alice & Bob
  await assertSucceeds(
    aliceDb.collection("chats").doc(chatId).set({
      chatId: chatId,
      type: "direct",
      participantUids: [ALICE_UID, BOB_UID],
      participantNames: { [ALICE_UID]: "Alice", [BOB_UID]: "Bob" },
      createdBy: ALICE_UID,
      createdAt: now,
    })
  );

  // Bob can get the chat
  await assertSucceeds(bobDb.collection("chats").doc(chatId).get());

  // Charlie cannot get the chat
  await assertFails(charlieDb.collection("chats").doc(chatId).get());

  // Alice sends a message
  const messageId = "msg_1";
  await assertSucceeds(
    aliceDb.collection("chats").doc(chatId).collection("messages").doc(messageId).set({
      messageId: messageId,
      chatId: chatId,
      senderId: ALICE_UID,
      senderName: "Alice",
      participantUids: [ALICE_UID, BOB_UID],
      text: "أهلاً وسهلاً بيك",
      type: "text",
      createdAt: now,
    })
  );

  // Bob can read the message
  await assertSucceeds(
    bobDb.collection("chats").doc(chatId).collection("messages").doc(messageId).get()
  );

  // Charlie cannot read the message
  await assertFails(
    charlieDb.collection("chats").doc(chatId).collection("messages").doc(messageId).get()
  );

  // Charlie cannot send a message to Alice and Bob's chat
  await assertFails(
    charlieDb.collection("chats").doc(chatId).collection("messages").doc("msg_charlie").set({
      messageId: "msg_charlie",
      chatId: chatId,
      senderId: CHARLIE_UID,
      senderName: "Charlie",
      participantUids: [ALICE_UID, BOB_UID],
      text: "تجسس",
      type: "text",
      createdAt: now,
    })
  );
});
